USE `adopciones`;

/*---------------------------PROCEDIMIENTOS PARA BUSCAR----------------------------------------*/

/*------Buscar persona----------*/
DELIMITER $$
DROP PROCEDURE IF EXISTS `buscarPersona` $$
create procedure `buscarPersona`(
	identificacion int
) 
begin
	select Persona.* from Persona where Persona.idPersona = identificacion;
END$$

/*---------------------------PROCEDIMIENTOS PARA INSERTAR--------------------------------------*/

/*------Registrar tipoDocumento----------*/
DELIMITER $$
DROP PROCEDURE IF EXISTS `registrarTpDocumento` $$
create procedure `registrarTpDocumento`(
	nombreDocumento varchar(45)
) 
begin
	insert into Tipo_Documento (tipoDocumento, estadoDocumento) values (nombreDocumento, "Activo");
END$$

/*------Registrar rol----------*/
DELIMITER $$
DROP PROCEDURE IF EXISTS `registrarRol` $$
create procedure `registrarRol`(
	rol varchar(45)
) 
begin
	insert into Roles (nombreRol, estadoRol) values (rol, "Activo");
END$$

/*------Registrar permiso----------*/
DELIMITER $$
DROP PROCEDURE IF EXISTS `registrarPermiso` $$
create procedure `registrarPermiso`(
	permiso varchar(45)
) 
begin
	insert into Permisos (nombrePermiso, estadoPermiso) values (permiso, "Activo");
END$$

/*------Registrar permiso-rol----------*/
DELIMITER $$
DROP PROCEDURE IF EXISTS `registrarPermisoRol` $$
create procedure `registrarPermisoRol`(
	nombreRol varchar(45),
    nombrePermiso varchar(45),
    nombreCarpetaVista varchar(45),
    nombreVista varchar(45)
) 
begin
	declare idrol int;
    declare idpermiso int;
    set idR = ObtenerIdRol(nombreRol);
    set idP = ObtenerIdPermiso(nombrePermiso);
	insert into Permisos_Roles (fk_idPermisos, fk_idRoles, vista_raiz, vista) values (idR, idP, nombreCarpetaVista, nombreVista);
END$$

/*------Registrar celular----------*/
DELIMITER $$
DROP PROCEDURE IF EXISTS `registrarCelular` $$
create procedure `registrarCelular`(
	numero varchar(10),
    idUsuario int
) 
begin
	declare  identificacion int;
    set identificacion =  ObtenerIdPersona(idUsuario);
	insert into Celular (numero, estadoNumero, Persona_idPersona) values (numero, "Activo", identificacion);
    /*buscar persona por id con funciones o con procedimiento*/
END$$

/*------Registrar ubicacion----------*/
DELIMITER $$
DROP PROCEDURE IF EXISTS `registrarUbicacion` $$
create procedure `registrarUbicacion`(
	ubicacion varchar(100),
    idUsuario int
) 
begin
	declare  identificacion int;
    set identificacion =  ObtenerIdPersona(idUsuario);
	insert into Celular (Ubicacion, estadoUbicacion, Persona_idPersona) values (ubicacion, "Activo", identificacion);
    /*buscar persona por id con funciones o con procedimiento*/
END$$

/*------Registrar correo----------*/
DELIMITER $$
DROP PROCEDURE IF EXISTS `registrarCorreo` $$
create procedure `registrarCorreo`(
	correo varchar(100),
    idUsuario int
) 
begin
	declare  identificacion int;
    set identificacion =  ObtenerIdPersona(idUsuario);
	insert into Celular (correoPersona, estadoCorreo, Persona_idPersona) values (ubicacion, "Activo", identificacion);
    /*buscar persona por id con funciones o con procedimiento*/
END$$    

/*------Registrar persona----------*/
DELIMITER $$
DROP PROCEDURE IF EXISTS `registrarPersona` $$
create procedure `registrarPersona`(
	identificacion int,
	nombre varchar(45),
    apellido varchar(45),
    edad int,
    telefono varchar(10),
    ubicacion varchar(100),
    correo varchar(100)
) 
begin
	insert into Persona (idPersona, nombrePersona, apellidoPersona, edadPersona) values (identificacion, nombre, apellido, edad);
    call registrarCelular(telefono, identificacion);
    call registrarUbicacion(ubicacion, identificacion);
    call registrarCorreo(correo, identificacion);
END$$ 