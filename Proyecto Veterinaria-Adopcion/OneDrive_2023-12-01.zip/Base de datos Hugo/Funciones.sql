USE `adopciones`;

/*---------------------------FUNCIONES PARA BUSCAR----------------------------------------*/

/*------buscar id de una persona------*/
DELIMITER //
CREATE FUNCTION ObtenerIdPersona(identificacion int)
RETURNS INT 
BEGIN
    DECLARE resultado int;
    SET resultado = (select Persona.idPersona from Persona where Persona.idPersona = identificacion);
    RETURN resultado;
END;

/*------buscar id de un rol por su nombre------*/
DELIMITER //
CREATE FUNCTION ObtenerIdRol(rol varchar(50))
RETURNS INT 
BEGIN
    DECLARE resultado int;
    SET resultado = (select Roles.idRol from Roles where Roles.nombreRol = rol);
    RETURN resultado;
END;

/*------buscar id de un permiso por su nombre------*/
DELIMITER //
CREATE FUNCTION ObtenerIdPermiso(permiso varchar(50))
RETURNS INT 
BEGIN
    DECLARE resultado int;
    SET resultado = (select Permisos.idPermiso from Permisos where Permisos.nombrePermiso = permiso);
    RETURN resultado;
END;